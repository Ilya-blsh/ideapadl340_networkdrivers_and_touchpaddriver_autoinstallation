/* This file is auto generated, version 201903032031 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201903032031 SMP Mon Mar 4 01:33:18 UTC 2019"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 8.2.0 (Ubuntu 8.2.0-21ubuntu1)"
